# LocalServe - Java Version (Servlets + JSP + JDBC + MySQL)

This is a **Java rewrite** of the original PHP "LocalServe" service-booking app,
built for the *Introduction to Java Programming (BCA)* PBL project.
Same features, same database concept — implemented with Java Servlets, JSP, and JDBC instead of PHP.

## Tech Stack
- Java (Servlets + JSP) — was PHP
- JDBC + MySQL — same MySQL database concept as before
- Apache Tomcat 9 (or any Servlet 4.0 compatible container)
- Maven (for building the WAR file)

## Features (same as original)
- User & Provider registration/login (role-based)
- User: dashboard, book a service, view my bookings, chat with provider
- Provider: dashboard, complete/update profile, view & accept/reject requests, earnings, chat with user

## Project Structure
```
src/main/java/com/localserve/
  util/        -> DBConnection.java, PasswordUtil.java
  auth/        -> LoginServlet, RegisterServlet, LogoutServlet
  user/        -> DashboardServlet, BookServlet, BookingsServlet, ChatServlet
  provider/    -> DashboardServlet, CreateProfileServlet, RequestsServlet, EarningsServlet, ChatServlet
src/main/webapp/
  auth/, user/, provider/   -> JSP pages (views)
database/schema.sql         -> MySQL tables
```

## How to Run

1. **Create the database**
   - Open MySQL and run:
     ```
     mysql -u root -p < database/schema.sql
     ```
   - This creates `localserve_db` with the `users`, `provider_details`, `bookings`, and `messages` tables.

2. **Set your DB credentials** (if different from default XAMPP/MySQL root with no password)
   - Edit `src/main/java/com/localserve/util/DBConnection.java` and update `DB_USER` / `DB_PASSWORD`.

3. **Build the WAR file**
   ```
   mvn clean package
   ```
   This produces `target/LocalServeJava.war`.

4. **Deploy to Tomcat**
   - Copy `LocalServeJava.war` into Tomcat's `webapps/` folder, start Tomcat.
   - Or in Eclipse/IntelliJ: import as a Maven project and "Run on Server" with Tomcat 9.

5. **Open in browser**
   ```
   http://localhost:8080/LocalServeJava/
   ```
   It redirects to the login page. Register a new "user" and a new "provider" account to try both roles.

## Notes for the Proposal / Report
- Passwords are hashed with SHA-256 (java.security.MessageDigest), replacing PHP's password_hash()/password_verify().
- SQL injection is prevented using PreparedStatement everywhere (parameterized queries), same protection goal as the original code intended.
- Session-based authentication uses HttpSession (equivalent of PHP's $_SESSION).
- Architecture: Browser -> Servlet (Controller) -> JDBC -> MySQL -> JSP (View). This is the classic Java **MVC-ish Servlet/JSP** pattern, a natural talking point for your "System Architecture" section in the proposal.
