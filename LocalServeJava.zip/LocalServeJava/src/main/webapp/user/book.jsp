<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.localserve.user.Provider" %>
<%@ page import="java.util.List" %>
<!DOCTYPE html>
<html>
<head>
<title>Book Service</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Poppins;}
body{display:flex;background:#f1f5f9;}
.sidebar{width:250px;height:100vh;background:linear-gradient(180deg,#0f172a,#1e293b);padding:20px;position:fixed;
    display:flex;flex-direction:column;justify-content:space-between;}
.logo{font-size:22px;font-weight:600;color:white;margin-bottom:30px;}
.sidebar a{display:flex;align-items:center;gap:10px;padding:12px;margin:10px 0;border-radius:10px;text-decoration:none;color:#cbd5e1;}
.sidebar a:hover,.active{background:linear-gradient(90deg,#2563eb,#3b82f6);color:white;}
.container{margin-left:270px;padding:50px;width:100%;}
.header{background:white;padding:25px;border-radius:15px;box-shadow:0 5px 20px rgba(0,0,0,0.08);margin-bottom:40px;}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:30px;}
.card{background:white;padding:25px;border-radius:18px;box-shadow:0 8px 25px rgba(0,0,0,0.08);transition:0.3s;}
.card:hover{transform:translateY(-6px);}
.price{color:#2563eb;font-weight:600;}
input, select{width:100%;padding:10px;margin-top:10px;border-radius:10px;border:1px solid #e2e8f0;}
.btn-group{display:flex;justify-content:space-between;margin-top:15px;}
.btn{padding:10px 18px;border:none;border-radius:10px;cursor:pointer;font-weight:500;}
.book{background:linear-gradient(90deg,#2563eb,#3b82f6);color:white;}
.msg{color:#16a34a;font-weight:600;margin-bottom:15px;}
</style>
</head>
<body>
<div class="sidebar">
<div>
<div class="logo">LocalServe (Java)</div>
<a href="${pageContext.request.contextPath}/user/dashboard"><i class="fa-solid fa-house"></i> Dashboard</a>
<a href="${pageContext.request.contextPath}/user/book" class="active"><i class="fa-solid fa-plus"></i> Book Service</a>
<a href="${pageContext.request.contextPath}/user/bookings"><i class="fa-solid fa-list-check"></i> My Bookings</a>
</div>
<a href="${pageContext.request.contextPath}/auth/logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
</div>
<div class="container">
<div class="header"><h2>Book Service</h2><p>Select provider and book easily</p></div>
<% if (request.getAttribute("msg") != null) { %>
<div class="msg"><%= request.getAttribute("msg") %></div>
<% } %>
<div class="grid">
<%
List<Provider> providers = (List<Provider>) request.getAttribute("providers");
if (providers != null) {
    for (Provider p : providers) {
%>
<div class="card">
<h3><%= p.service %></h3>
<p class="price">Rs. <%= p.pricePerHour %>/hr</p>
<p>Experience: <%= p.experience %> yrs | Phone: <%= p.phone %></p>
<form method="POST" action="${pageContext.request.contextPath}/user/book">
<input type="hidden" name="provider_id" value="<%= p.userId %>">
<input type="date" name="date" required>
<select name="time" required>
<option value="">Select Time</option>
<option>9 AM - 11 AM</option>
<option>11 AM - 1 PM</option>
<option>1 PM - 3 PM</option>
<option>3 PM - 5 PM</option>
<option>5 PM - 7 PM</option>
</select>
<div class="btn-group">
<button class="btn book" type="submit">Book Now</button>
</div>
</form>
</div>
<% } } %>
</div>
</div>
</body>
</html>
