<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
<title>Create Profile</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Poppins;}
body{height:100vh;display:flex;justify-content:center;align-items:center;background:linear-gradient(135deg,#0f172a,#1e293b,#2563eb);}
.card{width:420px;padding:35px;border-radius:20px;background:rgba(255,255,255,0.08);backdrop-filter:blur(18px);
    box-shadow:0 20px 40px rgba(0,0,0,0.3);color:white;}
.title{text-align:center;margin-bottom:25px;font-size:22px;font-weight:600;}
.msg{text-align:center;margin-bottom:15px;color:#ffcc00;}
input, select{width:100%;padding:12px;margin-bottom:12px;border:none;border-radius:10px;outline:none;background:rgba(255,255,255,0.15);color:white;}
.custom-select option{background:#1e293b;color:white;}
button{width:100%;padding:12px;border:none;border-radius:10px;background:linear-gradient(90deg,#22d3ee,#06b6d4);
    color:black;font-weight:600;margin-top:5px;cursor:pointer;}
</style>
</head>
<body>
<form method="POST" class="card" action="${pageContext.request.contextPath}/provider/create-profile">
<div class="title"><i class="fa-solid fa-user-gear"></i> Complete Profile</div>
<div class="msg"><%= request.getAttribute("msg") != null ? request.getAttribute("msg") : "" %></div>
<input type="text" name="name" placeholder="Enter Your Name" required>
<select name="service" required class="custom-select">
<option value="">Select Service</option>
<option>Plumber</option><option>Electrician</option><option>Carpenter</option>
<option>Painter</option><option>AC Repair</option><option>Fridge Repair</option>
<option>Washing Machine Repair</option><option>TV Repair</option><option>Mobile Repair</option>
<option>Laptop Repair</option><option>Beautician</option><option>Hair Stylist</option>
<option>Home Cleaning</option><option>Pest Control</option><option>Gardener</option>
<option>Driver</option><option>Cook</option><option>Tutor</option><option>Photographer</option>
</select>
<input type="number" name="price" placeholder="Price Per Hour" step="0.01" required>
<input type="text" name="phone" placeholder="Phone Number" required>
<input type="number" name="exp" placeholder="Experience (years)" required>
<button type="submit"><i class="fa-solid fa-floppy-disk"></i> Save Profile</button>
</form>
</body>
</html>
