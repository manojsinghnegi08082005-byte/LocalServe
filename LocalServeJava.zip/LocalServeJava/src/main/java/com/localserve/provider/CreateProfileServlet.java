package com.localserve.provider;

import com.localserve.util.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/provider/create-profile")
public class CreateProfileServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/provider/create_profile.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            resp.sendRedirect(req.getContextPath() + "/auth/login");
            return;
        }

        int providerId = (int) session.getAttribute("user_id");
        String name = req.getParameter("name");
        String service = req.getParameter("service");
        double price = Double.parseDouble(req.getParameter("price"));
        String phone = req.getParameter("phone");
        int exp = Integer.parseInt(req.getParameter("exp"));

        String msg;
        try (Connection conn = DBConnection.getConnection()) {
            // requires a UNIQUE constraint on provider_details.user_id (see schema.sql)
            String sql = "INSERT INTO provider_details (user_id, name, service, price_per_hour, phone, experience) " +
                    "VALUES (?,?,?,?,?,?) " +
                    "ON DUPLICATE KEY UPDATE name=VALUES(name), service=VALUES(service), " +
                    "price_per_hour=VALUES(price_per_hour), phone=VALUES(phone), experience=VALUES(experience)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, providerId);
                ps.setString(2, name);
                ps.setString(3, service);
                ps.setDouble(4, price);
                ps.setString(5, phone);
                ps.setInt(6, exp);
                ps.executeUpdate();
            }
            msg = "Profile Saved";
        } catch (Exception e) {
            msg = "Error: " + e.getMessage();
        }

        req.setAttribute("msg", msg);
        req.getRequestDispatcher("/provider/create_profile.jsp").forward(req, resp);
    }
}
