package com.localserve.provider;

public class BookingRequest {
    public int id;
    public String userName;
    public String bookingDate;
    public String timeSlot;
    public String status;

    public BookingRequest(int id, String userName, String bookingDate, String timeSlot, String status) {
        this.id = id;
        this.userName = userName;
        this.bookingDate = bookingDate;
        this.timeSlot = timeSlot;
        this.status = status;
    }
}
