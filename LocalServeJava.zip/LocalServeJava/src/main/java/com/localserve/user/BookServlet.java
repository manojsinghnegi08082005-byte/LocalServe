package com.localserve.user;

import com.localserve.util.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/user/book")
public class BookServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        showProviders(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            resp.sendRedirect(req.getContextPath() + "/auth/login");
            return;
        }

        int userId = (int) session.getAttribute("user_id");
        int providerId = Integer.parseInt(req.getParameter("provider_id"));
        String date = req.getParameter("date");
        String time = req.getParameter("time");

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO bookings (user_id, provider_id, status, booking_date, time_slot) " +
                    "VALUES (?,?,'pending',?,?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, userId);
                ps.setInt(2, providerId);
                ps.setString(3, date);
                ps.setString(4, time);
                ps.executeUpdate();
            }
            req.setAttribute("msg", "Booking Sent");
        } catch (Exception e) {
            req.setAttribute("msg", "Error: " + e.getMessage());
        }

        showProviders(req, resp);
    }

    private void showProviders(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        List<Provider> providers = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT user_id, service, price_per_hour, phone, experience FROM provider_details";
            try (PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    providers.add(new Provider(
                            rs.getInt("user_id"),
                            rs.getString("service"),
                            rs.getDouble("price_per_hour"),
                            rs.getString("phone"),
                            rs.getInt("experience")
                    ));
                }
            }
        } catch (Exception e) {
            req.setAttribute("error", e.getMessage());
        }

        req.setAttribute("providers", providers);
        req.getRequestDispatcher("/user/book.jsp").forward(req, resp);
    }
}
