package com.localserve.user;

public class Provider {
    public int userId;
    public String service;
    public double pricePerHour;
    public String phone;
    public int experience;

    public Provider(int userId, String service, double pricePerHour, String phone, int experience) {
        this.userId = userId;
        this.service = service;
        this.pricePerHour = pricePerHour;
        this.phone = phone;
        this.experience = experience;
    }
}
