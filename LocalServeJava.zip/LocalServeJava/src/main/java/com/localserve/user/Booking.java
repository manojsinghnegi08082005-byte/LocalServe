package com.localserve.user;

public class Booking {
    public int id;
    public String service;
    public String bookingDate;
    public String timeSlot;
    public String status;

    public Booking(int id, String service, String bookingDate, String timeSlot, String status) {
        this.id = id;
        this.service = service;
        this.bookingDate = bookingDate;
        this.timeSlot = timeSlot;
        this.status = status;
    }
}
